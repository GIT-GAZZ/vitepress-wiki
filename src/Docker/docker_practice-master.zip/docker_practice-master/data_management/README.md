# Docker 数据管理

![](./_images/types-of-mounts.png)

这一章介绍如何在 Docker 内部以及容器之间管理数据，在容器中管理数据主要有两种方式：

* 数据卷（Volumes）

* 挂载主机目录 (Bind mounts)
