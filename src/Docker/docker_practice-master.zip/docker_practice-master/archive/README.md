# 归档项目

以下项目不被官方支持或内容陈旧，将在下一版本中删除（或已经删除）。

* [Docker Machine](https://github.com/yeasy/docker_practice/tree/ca29ab51b121f43563f5d6659dedbda5cb6f048d/machine)
* [Docker Swarm](https://github.com/yeasy/docker_practice/tree/ca29ab51b121f43563f5d6659dedbda5cb6f048d/swarm)
* Mesos
