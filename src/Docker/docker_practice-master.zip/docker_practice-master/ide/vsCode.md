# VS Code 中使用 Docker

## 将 Docker 容器作为远程开发环境

无需本地安装开发工具，直接将 Docker 容器作为开发环境，具体参考 [官方文档](https://code.visualstudio.com/docs/remote/containers)。
